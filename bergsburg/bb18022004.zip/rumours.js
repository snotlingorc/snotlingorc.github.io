
var rumours = new Array(	
	"null - dummy element",
"<p><div align=justify><i>&quot;There's actually a seam of gold underneath the city itself! The Prospector's Guild have hushed it up, and no-one knows where it is.&quot;</i></div>",

"<p><div align=justify><i>&quot;There's a gold seam under the city but they can't get to it coz the whole undercity is riddled with Skaven.&quot;</i></div>",

"<p><div align=justify><i>&quot;The Bretonnian art dealer Henri D'Albuisse is secretly a wizard.&quot;</i></div>",

"<p><div align=justify><i>&quot;You can buy anything you want from the docks in Helmsberg, but they have their own special kind of 'tax'.&quot;</i></div>",

"<p><div align=justify><i>&quot;Malkus Pflaubert has discovered true transmutation, but it has driven him mad.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a blind beggar that's been cured up at the falls.  They say his eyes grew back!&quot</i></div>",

"<p><div align=justify><i>&quot;There is a ghostly city watchman that appears at midnight on the walls between the temple and the Lowentor.  He is said to look towards the falls, cower and then disappear with a silent scream. If you see it, eat a whole onion that day, or you'll be dead within the year.&quot</i></div>",

"<p><div align=justify><i>&quot;Helmsberg hill is haunted by hanged murderers, they will never find peace. The only way to get about there safely is to carry a copy of the laws of Verena. If you see them, eat a whole onion, that day, or you'll be dead within the year.&quot</i></div>",

"<p><div align=justify><i>&quot;A spectral white hound roams the forests of Hochland. If you see it, eat a whole onion that same day or you'll be dead within the year.&quot;</i></div>",

"<p><div align=justify><i>&quot;The white hound is actually blessed by Shallya. It protects pilgrims travelling to and from the temple.&quot</i></div>",

"<p><div align=justify><i>&quot;The council of Five is dominated by Erasmus Vogel, whatever he says, goes. Bianka Morgentau stood up to him once, and he turned her into a newt. He only changed her back when she promised not to interfere.&quot</i></div>",

"<p><div align=justify><i>&quot;Ragnar Stonehammer has a huge magic gemstone that will bring wealth to whoever possesses it. A dwarven princess gave it to him.&quot;</i></div>",

"<p><div align=justify><i>&quot;The Nitche brothers at Praxis? Those boys aren't right. Their mother drove their father to suicide and they haven't been the same since.&quot</i></div>",

"<p><div align=justify><i>&quot;The Baroness's Men are rubbish. They're only tolerated in a provincial backwater like this. If they were in Altdorf or Nuln, they'd get laughed off the stage.&quot;</i></div>",

"<p><div align=justify><i>&quot;The Baroness's Men are a wonderful troupe. Bergsburg is certainly blessed to have them. I saw 'The Estalian Tragedy' the other day. It moved me to tears. Stefan Glaublich's 'Asperro' was absolutely wonderful.&quot</i></div>",

"<p><div align=justify><i>&quot;If you've got too many cats, Jakob Kelden will look after them for you. He loves cats.&quot</i></div>",

"<p><div align=justify><i>&quot;One of the guys at the Weissfeuer Smithy, is a human that pretends to be a dwarf, or is he a dwarf pretending to be a human, either way it's pretty funny.&quot</i></div>",

"<p><div align=justify><i>&quot;Everyone in Altdorf has to wear silk slippers, it's the law. They do that so no one damages the gold paved streets.&quot</i></div>",

"<p><div align=justify><i>&quot;Fikentscher's Divine Healing Potion is the best thing ever. It will cure almost anything. I heard someone had scabies once.&quot</i></div>",

"<p><div align=justify><i>&quot;Someone told me that you can tell if someones good or bad, just by measuring their head.&quot</i></div>",

"<p><div align=justify><i>&quot;The watch in Beilheim are as bent as they come.&quot;</i></div>",

"<p><div align=justify><i>&quot;Bezahlenstrasse in Beilheim is full of ladies of ill repute. The Watch there take backhanders to turn a blind eye.&quot</i></div>",

"<p><div align=justify><i>&quot;A huge army of greenskins is massing in the Middle Mountains. They're lead by a huge black Orc called Grobsnout who has his heart set on marrying Simone von Tussen-Hochen.&quot</i></div>",

"<p><div align=justify><i>&quot;The sculptures on the Lowentor are not really lions at all, they're tigers and they'll come to life if they city is threatened with destruction.&quot</i></div>",

"<p><div align=justify><i>&quot;Johann Sainzburg runs the best food stall in Grossplatz. Jem Hollyburr buys all his stuff there.&quot</i></div>",

"<p><div align=justify><i>&quot;Sainzburg's food is rubbish.  You need to try Hubert Tesskau's stall instead.&quot</i></div>",

"<p><div align=justify><i>&quot;Heinz Sommerfeld has cheap but fresh vegetables and fruit for sale. You can't get better value, although you'll have to push through the rabble to get to it.&quot</i></div>",

"<p><div align=justify><i>&quot;Don't trust the elves.  They can see what you are thinking, and they steal human babies to feed to the trees.&quot</i></div>",

"<p><div align=justify><i>&quot;Lothar swears that he saw something he called a 'monkey' scampering up the walls the other night. Mind you, he'd had a few...&quot</i></div>",

"<p><div align=justify><i>&quot;That Wildfeuer woman that runs the brothel?  She's actually a man.&quot</i></div>",

"<p><div align=justify><i>&quot;If you look carefully, you can see the face of Taal in the cliffs to the left of the falls.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a tunnel leads from the palace down to the Temple of Shallya underneath the falls themselves.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a tunnel leads from under the Cathedral of Sigmar to outside the city walls.  They were going to use it if the Ulricans ever attacked the city.&quot</i></div>",

"<p><div align=justify><i>&quot;Have you heard?  Joachim Faxenmacher's Fantastical Entertainment is coming to town!  Apparently they have lions and clowns from Araby!&quot</i></div>",

"<p><div align=justify><i>&quot;A dancing bear got loose in Grossplatz yesterday.  It lumbered about a bit before being subdued by the owner.  Still... could have been nasty.&quot</i></div>",

"<p><div align=justify><i>&quot;The Council want to introduce a new tax on chimneys.  Sounds like a good idea to me.&quot</i></div>",

"<p><div align=justify><i>&quot;There are no rats in Bergsburg.  They're too frightened of Shallya.  (a rat should then scamper across the room behind the teller of this rumour)&quot</i></div>",

"<p><div align=justify><i>&quot;An apple cart overturned on Roland's Bridge this morning.  Spilled it's load into the river - you could see them trying to fish them out down by St. Skulda's bridge.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a dragon lives up in the Middle Mountains.  Some drunken dwarf told me in the Pedlar's Rest the other night - apparently it's got more gold crowns than I've got grey hairs!&quot</i></div>",

"<p><div align=justify><i>&quot;Some street urchins have taken to pelting passers by with eggs in Sudentor.  Waste of good eggs, I reckon.&quot</i></div>",

"<p><div align=justify><i>&quot;Old Otto Weber is sleeping with Einar Schlaghose's wife.  Everyone knows it apart from poor Einar.&quot</i></div>",

"<p><div align=justify><i>&quot;The Rolling Stones is the place to go for a good game of cards or dice. But the stakes are high.&quot;</i></div>",

"<p><div align=justify><i>&quot;Some noble lost his entire estate to a fishmonger, at The Rolling Stones. He was gutted. So was the fishmonger, a few days later.&quot</i></div>",

"<p><div align=justify><i>&quot;All the gold that the prospectors guild get is transported around the empire by magical means.&quot;</i></div>",

"<p><div align=justify><i>&quot;The Bergsburg gold is transported in the dead of night under the new moon by mysterious cloaked figures. I've seen them.&quot;</i></div>",

"<p><div align=justify><i>&quot;They actually use a dwarven submarine to take the Bergsburg gold downriver.&quot</i></div>",

"<p><div align=justify><i>&quot;The temple of Ulric is infested with rats.&quot</i></div>",

"<p><div align=justify><i>&quot;Paul Rachov was a nutter. He tried to kill a load of Sigmarites just for the fun of it. Everything the church of Ulric says about him is simply made up to make them look good.&quot</i></div>",

"<p><div align=justify><i>&quot;St. Franz was a nutter. He tried to kill a load of Ulricans just for the fun of it. Everything the church of Sigmar says about him is simply made up to make them look good.&quot</i></div>",

"<p><div align=justify><i>&quot;During Pie Week, in Erntezeit, everybody eats loads, except the cooks who don't eat at all.&quot</i></div>",

"<p><div align=justify><i>&quot;Rudolf Geissman and Martin Mueller form the temple of St Franz are always arguing, they can't seem to agree on anything.&quot</i></div>",

"<p><div align=justify><i>&quot;Albrecht Rutiger, a prospector, has found a load of gold, and is trying to keep it secret from the Prospectors Guild. He's not doing a very good job of it, coz he's spending like a nob.&quot</i></div>",

"<p><div align=justify><i>&quot;Hugo Zungenbrecher's only got one leg. He chopped the other off coz it mutated into a cloven hoof.&quot</i></div>",

"<p><div align=justify><i>&quot;Berthold Kant's only got one leg. He chopped the other off coz it mutated into a cloven hoof.&quot</i></div>",

"<p><div align=justify><i>&quot;Kurt Brombeer's only got one leg. He chopped the other off coz it mutated into a cloven hoof.&quot</i></div>",

"<p><div align=justify><i>&quot;Stefan Glaublich's only got one leg. He chopped the other off coz it mutated into a cloven hoof.&quot</i></div>",

"<p><div align=justify><i>&quot;Check out Dirk Potbelly's chicken soup at the Gold Nugget Inn. It's the best meal I've had since I came here.&quot</i></div>",

"<p><div align=justify><i>&quot;Have you ever tried snotling? It tastes just like chicken.&quot</i></div>",

"<p><div align=justify><i>&quot;Do you like Snotling? I don't know, I've never Snotled.&quot</i></div>",

"<p><div align=justify><i>&quot;Don't mess with the bouncers at the Gold Nugget Inn. The pair of them are absolute nutters.&quot</i></div>",

"<p><div align=justify><i>&quot;You can get almost any map you need at Brombeer's Cartographia. They're not cheap, but usually worth every penny.&quot;</i></div>",

"<p><div align=justify><i>&quot;Brombeer's a charlatan, or just crazy. He thinks the world is round. He makes up fantastical maps from imaginary lands across the sea and he has maps of the stars, as if anyone could travel to the stars.&quot</i></div>",

"<p><div align=justify><i>&quot;If you want to get to Wolfenburg quickly, go with Vlarin Onkling and his caravan. They'll get you there in no time. They're preparing to leave very soon.&quot;</i></div>",

"<p><div align=justify><i>&quot;Don't go anywhere with Vlarin Onkling. He leads you up into the mountains then murders you and takes all your stuff. I had a friend who went with him to Wolfenburg, never came back.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a shrine to Ranald in Backerstrasse.&quot</i></div>",

"<p><div align=justify><i>&quot;Two elves walked into a bar in Osttor and said 'Ouch'. It was The Iron Bar.&quot</i></div>",

"<p><div align=justify><i>&quot;Old Mother Winne had a dream last night. She dreamt the drak filled with blood and ran with the bodies of dead doves, their white feathers all stained red. Then a dragon flew down from the Middle Mountains and feasted on the cattle of Viehstadt.&quot;</i></div>",

"<p><div align=justify><i>&quot;Last time Old Mother Winne had a dream she said it was gonna rain for forty days and we'd all get washed down the river. We had some lovely weather after that.&quot</i></div>",

"<p><div align=justify><i>&quot;Went to the Tiegel last night, Sigmar and Kargan. Those special effects were wonderful. The battle scene, it took me back to my time in the Hochland Free Company. If I didn't know better, I'd swear it was magic.&quot</i></div>",

"<p><div align=justify><i>&quot;Went to the Tiegel last night, The Metamorphosis of Paracello, very good, I liked it a lot, reminded me of something else though. It's on the tip of my tongue, I'll get it in a minute.&quot</i></div>",

"<p><div align=justify><i>&quot;Went to the Tiegel last night, The Sultan's Lament. Not bad, I thought that schonheit girl was a bit overdressed though, after all its hot in Araby, isn't it. Those costumes though, reminded me of someone, can't remember who, it's on the tip of my tongue.&quot</i></div>",

"<p><div align=justify><i>&quot;Went to the Tiegel last night, That Which Can Be. What a load of pretentious twaddle.&quot</i></div>",

"<p><div align=justify><i>&quot;On Geheimnisnacht the ghost of Ulgarth One-eye appears in trade town. He's out to avenge his betrayal, by his fellow prospectors. If you see it, eat a whole onion that day or you'll be dead within the year.&quot</i></div>",

"<p><div align=justify><i>&quot;If you want to do business in southern Beilheim, get in with Georg Bierle, he's got the place sown up. Half the people that live there are related to him in some way.&quot</i></div>",

"<p><div align=justify><i>&quot;If you like a good knees up try The Dancing Landlord in Verenenstadt. They let me recite some of me poetry. It went down a storm I tell you.&quot</i></div>",

"<p><div align=justify><i>&quot;Theres a magic glade down the river where you can get lost forever. If you run into by mistake then you'll never get out again unless you've been loyal to Shallya.&quot</i></div>",

"<p><div align=justify><i>&quot;That looks serious. Goody Gretchen will sort that out for you. She'll help anyone. A friend of mine had pustules, she had him better within the week, didn't charge him a penny.&quot</i></div>",

"<p><div align=justify><i>&quot;Old Wertheim is on his deathbed, one of the richest men in Bergsburg and no one to give it all to. One of his sons is never here, and he doesn't want to give it to the other in case his grandson gets hold of it.&quot</i></div>",

"<p><div align=justify><i>&quot;The thing about the Kreuzers is, they only take money from the rich, and they're always ready to help anyone in real need.&quot</i></div>",

"<p><div align=justify><i>&quot;Have you heard? There's a new tax on the way... the Town Hall want to levy a shilling on velvet hats!&quot</i></div>",

"<p><div align=justify><i>&quot;There's an old woman that lives in Sudentor with about 100 cats! I think she feeds them on drunks that she finds in the street.&quot</i></div>",

"<p><div align=justify><i>&quot;Did you see that? Just then! Some kids riding goats down Kurtstrasse... whatever next?&quot</i></div>",

"<p><div align=justify><i>&quot;Hochland Crossing have a vacancy for a coach driver now that Erwin Zimmerman has run off to Middenheim with a stripper.&quot</i></div>",

"<p><div align=justify><i>&quot;The present owner of the Last Inn, Hasselus von Fabibaink of Middenheim, hasn't ever visited Bergsburg, but made the purchase on the advice of his financial advisors.&quot</i></div>",

"<p><div align=justify><i>&quot;Don't mess with the cat in the Gold Nugget Inn, I saw a guy shoo the cat away from eating his stew and a bouncer came over and broke his nose!&quot</i></div>",

"<p><div align=justify><i>&quot;Have you seen that old druid that turns up in the trade town selling honey?  He must be *minted*&quot</i></div>",

"<p><div align=justify><i>&quot;Br. Thomas from the monastery keeps asking weird questions to all and sundry in Helmsberg. It seems that the Kreuzers got scared about something and plan to stop his questions, if ya' know what I mean...&quot</i></div>",

"<p><div align=justify><i>&quot;Thousands of years ago, The Last Inn used to be a temple of Old Faith. The Staff, and some of the customers, turn into wolves at night.&quot</i></div>",

"<p><div align=justify><i>&quot;I have it from reliable sources that the dumb librarian at the Verenan library is hiding diabolic scriptures in there. I'm sure they would be worth a good deal of gold, if you find the right customer!&quot</i></div>",

"<p><div align=justify><i>&quot;St Franz's pendant works miracles! My uncle's cousin kissed it yesteryear, and he singlehandedly struck down two bandits on the road to Middenheim in the following month!&quot</i></div>",

"<p><div align=justify><i>&quot;If you want real miracles, you have to line up with the rest of them for the sacred waters of Shallya.&quot</i></div>",

"<p><div align=justify><i>&quot;If you seek healing, you could try the Sacred Flame at the Ulrican temple. Pieter's father had his arm healed in the holy flames when I was a little boy.&quot;</i></div>",

"<p><div align=justify><i>&quot;The Schattentals have a secret, though nobody knows what it is.&quot</i></div>",

"<p><div align=justify><i>&quot;The thing about Bergsburg is that during the Chaos Wars, this place was barely affected. You tell me why that was, then.&quot</i></div>",

"<p><div align=justify><i>&quot;Don't bother going to Stubfoot's Instant Pawn, there's nothing there.&quot</i></div>",

"<p><div align=justify><i>&quot;Apparently the architect for the Temple of the Falls was influenced by the mosques they have in Araby.&quot</i></div>",

"<p><div align=justify><i>&quot;Hey!  Are you... Is it... you're that bloke from the theatre, aren't you?  That Blausinger one?  Yeah, me and the wife love all your plays...Oh.. sorry.  You do look like him though.&quot</i></div>",

"<p><div align=justify><i>&quot;You look a bit peaky - go and get yourself some turnip soup from Helmsburg.  That'll have you right in no time.&quot</i></div>",

"<p><div align=justify><i>&quot;If you need Black Lotus, go to the String O' Pearls. Tell them Rutger sent you.&quot</i></div>",

"<p><div align=justify><i>&quot;Someone said Brother Gianni Werberung of the temple of Verena has been to Lustria, but I don't think he has even been to Garssen.&quot</i></div>",

"<p><div align=justify><i>&quot;Gerhart was held up by some mean looking guys with masks. They told him to stop his heretical preachings - Verena knows, what they are talking about; all he did was discussing some old Ulrican scriptures with Fr. Andreas from the True Light monastery - and just how did they hear about that?&quot</i></div>",

"<p><div align=justify><i>&quot;Mind you, don't ever go to the Golden Boar - its snobby, and the food isn't worth the silver.&quot</i></div>",

"<p><div align=justify><i>&quot;Did you hear? One of the Councillors suggested they remove some tax or something... whatever it was, old Beierle was pretty excited about it!&quot</i></div>",

"<p><div align=justify><i>&quot;See that up there, yes, that huge bird, off towards the mountains. That means someone's died, that does.&quot</i></div>",

"<p><div align=justify><i>&quot;Remember that rich dwarf who arrived a few weeks ago with a small retinue and all? Well, my cousin is a servant at the palace, and she said he had long private talks with the Baroness yesterday. And that wasn't the first time, either!&quot</i></div>",

"<p><div align=justify><i>&quot;Oh my, that rich dwarf from the Mountains is a dwarf all right! Me and them other beggars have been working him since he got here, and he hasn't given up a single penny yet.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a half-orc lives in Helmsburg.  He's a beggar, but you can tell he's got goblin blood from his eyes.&quot</i></div>",

"<p><div align=justify><i>&quot;One of the wharves at Ostkai is all rotten.  It's going to collapse into the river any day now.&quot</i></div>",

"<p><div align=justify><i>&quot;The Kreuzers have a problem with Marius Balkan, and they've sabotaged one of his wharves.  It's going to collapse into the river any day now...&quot</i></div>",

"<p><div align=justify><i>&quot;The Temple are giving away bread in the Grossplatz!  Get yourself down there - I just got two loaves!&quot</i></div>",

"<p><div align=justify><i>&quot;The main thing you have to remember about Bergsburg, is that the 'e' comes before the 'u'.&quot</i></div>",

"<p><div align=justify><i>&quot;The Guldbergs, I don't like them. They've got their filthy little thieving hands all over this town. And they're taking our jobs.&quot</i></div>",

"<p><div align=justify><i>&quot;If you touch the Scharfstein, you can say anything you like.&quot</i></div>",

"<p><div align=justify><i>&quot;Around Schnittstrasse, there's too many young men with too much money, if you ask me.&quot</i></div>",

"<p><div align=justify><i>&quot;'The Rolling Stones' expanded into the premises next door, but they forgot to tell the City Surveyor.&quot</i></div>",

"<p><div align=justify><i>&quot;Have you noticed all that hustle and bustle at the Ludenhof mansion? Looks like the Count is coming to town. I reckon there'll be money to be made in Harzel, then...&quot</i></div>",

"<p><div align=justify><i>&quot;The problem with the City Watch is that they're always late.&quot</i></div>",

"<p><div align=justify><i>&quot;Need some gold jewellery? Avoid that Andreas bloke, he is overrated. I'd go to Ragnar.&quot</i></div>",

"<p><div align=justify><i>&quot;I don't trust those priests of Morr. They're good at what they do and all, but they have a quota system. If they don't get enough bodies, well, you can imagine, can't you.&quot</i></div>",

"<p><div align=justify><i>&quot;I hear there's a carnival coming to town next week, I hope they have some bearded ladies, they're my favourite.&quot</i></div>",

"<p><div align=justify><i>&quot;That Spalte Altfeld guy is spreading bad rumours about the priests of Morr. I'd stick to my barrels, if I were him. I mean, before he knows it, he'll be at the gate of Morr himself, right?&quot</i></div>",

"<p><div align=justify><i>&quot;Once, a long time ago, the whole of Hochland was under water, even the mountains.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a Necromancer staying at 'The Rolling stones'.&quot</i></div>",

"<p><div align=justify><i>&quot;Young Terkel is training hard for the snotball game at the Rolandsfest. Seems he wants to make a good impression on one of the Beierle girls. Y'know, some one should tell him that he should rather suck up to the old Nutcracker if he wants one of them Beierle girls.&quot</i></div>",

"<p><div align=justify><i>&quot;Rudolf Retrender has got some interesting stuff. You wouldn't want to be left alone with him though. He talks to his crossbow like it's his best friend.&quot</i></div>",

"<p><div align=justify><i>&quot;That Judge Eisennagel, he ordered another torture today. He won't be happy till the streets are running with blood.&quot</i></div>",

"<p><div align=justify><i>&quot;Them bureaucrats up at the Rathaus are just meddlers. They confiscated my cabbage barrow 'cos I couldn't pay the cabbage tax... Wait a minute... *is* there a cabbage tax?&quot</i></div>",

"<p><div align=justify><i>&quot;I wonder what Pol von Ludenhof is up to these days? We don't see him in the Dancing Landlord any more.&quot</i></div>",

"<p><div align=justify><i>&quot;The Wizard's Guild, they say it's twice as big on the inside as it is on the outside.&quot</i></div>",

"<p><div align=justify><i>&quot;I heard that one of the scribes in the Rathaus spelled Heidi Beierle's name wrong on some official document, and two days later he gets the sack! They're a powerful bunch that family.&quot</i></div>",

"<p><div align=justify><i>&quot;If you're thinking of a nice tasty blue cheese, which is crumbly but still has that creamy texture, you should try Grubentreich.&quot</i></div>",

"<p><div align=justify><i>&quot;I heard that the Rathaus is looking for some people to go out and take a survey of Osttor for a new map of the city.  Apparently it's a well-paid job, and they'll take anyone who knows how to use the right end of a quill.&quot</i></div>",

"<p><div align=justify><i>&quot;I saw one of those Detlef Sierck plays in Altdorf. Gods, it was fantastic! They should do more of his stuff at Tiegel's.&quot</i></div>",

"<p><div align=justify><i>&quot;I hear there's a carnival coming to town next week, I hope they have some three-legged goblins, they're my favourite.&quot</i></div>",

"<p><div align=justify><i>&quot;There's a carnival coming to town!  I hope they've got one of those singing donkeys - they're my favourite!&quot</i></div>",

"<p><div align=justify><i>&quot;I was up by the Schicksaltor yesterday, and I saw a bunch of prospectors coming back from the mountains.  They were carrying the body of some sort of monster that they'd killed... no idea what it was, but it didn't look natural.&quot</i></div>",

"<p><div align=justify><i>&quot;I hear there's a carnival coming to town next week, I hope they have some Grubentreich, it's my favourite.&quot</i></div>",

"<p><div align=justify><i>&quot;Grubentreich is the best bit of goat's cheese you can get this side of Parravon. Doesn't compare to the Bretonnian stuff, though.&quot</i></div>",

"<p><div align=justify><i>&quot;They say the Duchess of Talabheim has a cottage near Bergsburg where she secretly meets her lover.&quot</i></div>",

"<p><div align=justify><i>&quot;Eeh.. Franz Kobler's put on loads of weight.&quot</i></div>",

"<p><div align=justify><i>&quot;I hear they are planning something big at the Rathaus. I don't know what exactly, but it should be ready within two months.&quot</i></div>",

"<p><div align=justify><i>&quot;Did you see that big hairy Norseman arguing with the guards on Lowentor?  He looked like he'd just stepped off the longboat from Olricstaad.&quot</i></div>",

"<p><div align=justify><i>&quot;Sigmar knows why, but a barrel of Bugman's Troll Brew was delivered to Altfeld Coopers last month. Before the dwarfs from the Iron Bar found out, it had dissappeared. I heard it ended up at the Crossed Hands, but not even the dwarfs wanted to go there.&quot</i></div>",

"<p><div align=justify><i>&quot;They say a prospector should always carry a snotling in a cage for good luck, or is that a miner?&quot</i></div>",

"<p><div align=justify><i>&quot;I tell you, I've seen vultures descend on the dead. They don't mess about. They're straight in there, ripping and tearing with their dirty little beaks&quot</i></div>",

"<p><div align=justify><i>&quot;Red Moon at night, Rhya's delight. Red Moon in the morn, Verena be warned.&quot</i></div>",

"<p><div align=justify><i>&quot;Apparently Faustus Asprill plays with toy soldiers, a man of his age, I wonder if he's losing his marbles.&quot</i></div>",

"<p><div align=justify><i>&quot;That Inquisitor, Johann Kramer, has contacts all over the city. You couldn't eat a lump of Grubentreich without him knowing about it.&quot</i></div>",

"<p><div align=justify><i>&quot;Have you noticed that old man that stands next to St. Skulda's Bridge all day looking serious?  He used to be in the Blue Oak Company, but he went a bit funny, and now he's convinced that he's guarding the old river gate from beastmen!&quot</i></div>",

"<p><div align=justify><i>&quot;That fat old dame in the Dancing Landlord has decided that wearing shoes 'saps her talent'.  Those battered old carbuncles on her feet are putting off the customers.&quot</i></div>",

"<p><div align=justify><i>&quot;The temple of Sigmar has St Franz's collar bone hidden somewhere in there. I wonder why they refuse to have it on display.&quot</i></div>",

"<p><div align=justify><i>&quot;It's really hard to get real Grubentreich these days. Apparently all their goats were hit by a mysterious disease. I have to make do with Grevenfeld, now.&quot</i></div>",

"<p><div align=justify><i>&quot;That Hubert Tesskau! He tried to pass off Grevenfeld as Grubentreich. Well, I went straight to the watch. They said they couldn't tell the difference.&quot</i></div>",

"<p><div align=justify><i>&quot;This is the life. I signed on to guard the population from the grim perils of crime and other evils, and what happens? I spend all afternoon eating cheese!&quot</i></div>",

"<p><div align=justify><i>&quot;That Helmut Schilfgras gave Maria a whole crown the other day.  She wouldn't tell me why.&quot</i></div>",

"<p><div align=justify><i>&quot;I met a watchman in Beilheim last week, and he was terrified! While watching the horizon from the tower over Schicksalstor, he spotted a giant figure with what appeared to be a bull's head feasting on a horse!&quot</i></div>",

"<p><div align=justify><i>&quot;Oh, I'm so glad the Lord Mayor has recovered since that accident on the slippery cobbles of Middenweg. Work has been piling up at the Rathaus, y'know!&quot</i></div>",

"<p><div align=justify><i>&quot;There's a nutter up at the scharfstein. Says we can take over the world or something. I think he's getting carried away...by the watch.&quot</i></div>",

"<p><div align=justify><i>&quot;Judge Vierauge is getting too old for his job. We'll all be better off when he retires. Last week he fined a ratcatcher, seven rats.&quot</i></div>",

"<p><div align=justify><i>&quot;You'll never break into the gold trade, son.  It's all sen up between the Prospector's Guild and Werner and Sohnen.  Even the Baroness doesn't get much of a look-in.&quot</i></div>",

"<p><div align=justify><i>&quot;Eurgh!  I just stood in something nasty on Ruhigerstrasse.  Those dung-collectors can't do their jobs right.&quot</i></div>",

"<p><div align=justify><i>&quot;That Adolfus Mannlich is a typical example of a failed prospector. Don't tell him that to his face mind you.&quot</i></div>",

"<p><div align=justify><i>&quot;They do a lovely rhubarb pie at The Jolly Peasant.  But, it was spoiled when that fat-tongued halfling chef came over and asked me if I was enjoying it.&quot</i></div>",

"<p><div align=justify><i>&quot;I had that Mina Schilfgras in here today. It was all I could do, not to give her a good slap.&quot</i></div>",

"<p><div align=justify><i>&quot;The Wizard's guild is slowly sinking into the river. It's only held up by magic. That's why you won't see any birds perched on the roof.&quot</i></div>",

"<p><div align=justify><i>&quot;Did you hear what Helmut Schilfgras did to that trumpeter in Grossplatz?  Apparently he made some comment about his daughter Mina and.. well.. he doesn't play his trumpet with his *mouth* any more.&quot</i></div>",

"<p><div align=justify><i>&quot;Nobody knows exactly how many people actually live in Bergsburg. They use to employ someone to count us, but we just wouldn't keep still.&quot</i></div>",

"<p><div align=justify><i>&quot;How do those halflings afford to live up in Rolandsbrucke?&quot</i></div>",

"<p><div align=justify><i>&quot;They say the moon's made of cheese. But which moon? And which cheese?&quot</i></div>",

"<p><div align=justify><i>&quot;There was a miracle in the market this morning. Some guy bought a bun that had the face of Goody Gretchen on it. They're taking it up the Temple to get it looked at.&quot</i></div>",

"<p><div align=justify><i>&quot;Stupid haflings, coming here and taking our jobs. Dietrich, the chef at The Sun Resplendent, got replaced with a hafling just last month.&quot</i></div>",

"<p><div align=justify><i>&quot;I saw a pair of halflings squabbling in Grossplatz the other day.  It was quite comical really.&quot</i></div>",

"<p><div align=justify><i>&quot;Some Rathaus clerk keeps writing Helmsburg instead of Helmsberg. HAHA, who can find a castle down there...&quot</i></div>",

"<p><div align=justify><i>&quot;One of the watch has got the sweating sickness. Zinsser told him to go home and rub himself with pig fat and frogwort.&quot</i></div>",

"<p><div align=justify><i>&quot;You can't believe a word you hear in the streets and taverns of Bergsburg. People think they know what they're talking about, but most of the time it's based on rumour and superstition.&quot</i></div>"
);