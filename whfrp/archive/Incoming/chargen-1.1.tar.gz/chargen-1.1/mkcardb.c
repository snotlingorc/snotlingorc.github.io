/* Do entry/exit dependanices in career database.  Probably slowly,
   but very quickly programmed */

#ifdef HAVE_CONFIG_H
#include "config.h"
#else
#define HAVE_CHDIR
#endif

#include <stdio.h>
#include <stdlib.h>

#ifdef HAVE_CHDIR
#include <unistd.h>
#endif

#include "career.h"

void
print_career(struct career *p)
{
  struct string *i;
  
  printf("!%s\n", p->name);
  printf("P%i %i %i %i %i %i %i %i %i %i %i %i %i %i\n",
	 p->advance.M, p->advance.WS, p->advance.BS, p->advance.S,
	 p->advance.T, p->advance.W, p->advance.I, p->advance.A,
	 p->advance.Dex, p->advance.Ld, p->advance.Int, p->advance.Cl,
	 p->advance.WP, p->advance.Fel);

  if (p->equiv != NULL)
    printf("Q%s\n", p->equiv);

  i = p->skills;
  while (i) {
    printf("S%i %s\n", i->chance, i->name);
    i = i->next;
  }
  
  i = p->entrys;
  while (i) {
    printf("F%s\n", i->name);
      i = i->next;
  }
  
  i = p->exits;
  while (i) {
    printf("E%s\n", i->name);
    i = i->next;
  }
}

int
main(void)
{
  /* Go where the data files are */
#ifdef HAVE_CHDIR
  if (chdir(LIB_DIR) != -1) {
    perror("Couldn't chdir to " LIB_DIR);
  }
#endif  

  init_career_db();

  link_career_db();

  each_career(print_career);

  return 0;
}
