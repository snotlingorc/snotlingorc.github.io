/* Utility functions for dice rolling */

#include <stdlib.h>
#include <ctype.h>

#ifdef DEBUG
#include <stdio.h>
#endif

#include "dice.h"

/* 	$Id: dice.c,v 1.3 1997/09/11 17:02:17 broonie Exp $	 */

#ifndef lint
static char vcid[] = "$Id: dice.c,v 1.3 1997/09/11 17:02:17 broonie Exp $";
#endif /* lint */

/* Roll nDd */
unsigned int 
d(unsigned int n, unsigned int d)
{
  unsigned int retval = 0;

  while (n) {
    retval += (int)((double)rand() / ((double)RAND_MAX + 1) * d) + 1;
    n--;
  }

  return retval;
}

/* Roll dice specified in string - return -1 on error */
unsigned int
ndn_str(char *str)
{
  unsigned int n = 0;
  unsigned int sides = 0;
  int mod = 0;
  int modflag = 0;
  
  /* Read in n */
  while (isdigit(*str)) {
    n = n * 10 + (*str - '0');
    str++;
  }

  /* No number before the D == 1 */
  if (n == 0)
    n = 1;

  /* Skip D */
  if (toupper(*str) == 'D')
    str++;
  else
    return -1;

  /* Read d */
  while (isdigit(*str)) {
    sides = sides * 10 + (*str - '0');
    str++;
  }

  if ((modflag = (*str == '-')) || *str == '+') {
    /* Parse mod */
    str++;

    while (isdigit(*str)) {
      mod = mod * 10 + (int)(*str - '0');
      str++;
    }

    if (modflag)
      mod *= -1;

  } else {
    if (sides == 0) {
      return -1;
    }
  }
  
#ifdef DEBUG
  printf("ndn_str: %dD%d+%d\n", n, sides, mod);
#endif

  return d(n, sides) + mod;
}
