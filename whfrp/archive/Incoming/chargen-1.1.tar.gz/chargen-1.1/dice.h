/* Utility functions for dice rolling */

/* Roll nDs */
unsigned int d(unsigned int n, unsigned int d);

/* Roll nDn (determined from string) - returns -1 on error */
unsigned int ndn_str(char *str);
