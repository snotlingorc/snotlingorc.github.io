#include <ctype.h>
#include <limits.h>
#include <stdlib.h>
#include <time.h>

#include "util.h"

/* 	$Id: util.c,v 1.2 1997/09/11 17:00:38 broonie Exp $	 */

#ifndef lint
static char vcid[] = "$Id: util.c,v 1.2 1997/09/11 17:00:38 broonie Exp $";
#endif /* lint */

/* Make a string lower case */
void
mk_lower(char *s)
{
  while (*s) {
    *s = tolower(*s);
    s++;
  }
}


void randomize(void)
{
    time_t timeval = time(NULL);
    unsigned char *ptr = (unsigned char *)&timeval;
    unsigned i, seed = 0;

    for (i = 0; i < sizeof timeval; i++)
        seed = seed * (UCHAR_MAX+2U) + ptr[i];

    srand(seed);
}
