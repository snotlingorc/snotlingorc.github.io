#include <stdlib.h>
#include <string.h>

#include "wfrp.h"
#include "dice.h"

/* 	$Id: skills.c,v 1.3 1997/09/11 17:01:49 broonie Exp $	 */

#ifndef lint
static char vcid[] = "$Id: skills.c,v 1.3 1997/09/11 17:01:49 broonie Exp $";
#endif /* lint */

/* Routines for managing lists of skills */

/* At some point, it should support having one string per name (ie,
   in the entire program).  The data structures are rather naff, too */

/* Add a skill uniquely to the list of skills */
int
add_string(const char *name, unsigned int chance, struct string **node)
{
  /* Traverse the list */
  while (*node && strcmp((*node)->name, name))
    node = &((*node)->next);
  
  /* If we're pointing at something, non-unique */
  if (*node)
    return -1;

  /* Space for node */
  if (!(*node = malloc(sizeof **node)))
    return -1;

  /* End of the line */
  (*node)->next = NULL;

  /* Name */
  if (!((*node)->name = malloc(strlen(name) + 1))) {
    *node = NULL;
    return -1;
  }

  /* Put it there */
  strcpy((*node)->name, name);
  (*node)->chance = chance;
  
  return 0;
}

void
prob_add_strings(struct string *src, struct string **dest)
{
  /* Traverse the list */
  while (src) {
    /* Add it? */
    if (d(1, 100) <= src->chance)
      (void)add_string(src->name, 100, dest);  /* FIXME */
    
    /* Next... */
    src = src->next;
  }
}

/* Recursively nuke the list */
void
delete_strings(struct string *target)
{
  if (target)
    delete_strings(target->next);
  else
    return;

  free(target);
}

/* Is s in the list list? */
int
in_string_list(const struct string *list, const char *s)
{
  while (list) {
    if (strcmp(list->name, s) == 0)
      return 1;
    list = list->next;
  }

  return 0;
}
