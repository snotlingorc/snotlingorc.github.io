#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "wfrp.h"
#include "career.h"

/* Career database manaagement */

/* This uses red-black trees to hold the database, and does delayed loading
   of the career data.  There is no apparent purpose in either of these
   things, apart from me playing around (well, it does make the program much
   nicer on ELKS if delayed loading is used).  Hashing might be a little more
   appropriate than rb trees, but on a database this small, who cares?   */

#define BUF_SIZ 1024

/* 	$Id: career.c,v 1.2 1997/09/11 17:03:54 broonie Exp $	 */

#ifndef lint
static char vcid[] = "$Id: career.c,v 1.2 1997/09/11 17:03:54 broonie Exp $";
#endif /* lint */

/* Career list structure  */
struct node {
  struct career *data;
  fpos_t location;
  char *name;
  struct node *l, *r;
  int red;
};

/* Gets a career off the disk */
void
load_career(struct node *p);

/* ****************** GLOBALS (ugh) ****************/
static FILE *db;
static struct node *base, *end;
static struct node *p, *x, *g, *gg;

/**************************** TREE MANAGEMENT **************************/

/* Initialize the tree */
int
init_tree()
{
  /* Sentinel */
  end = malloc(sizeof *end);
  if (end == NULL) {
    fprintf(stderr, "Can't setup list data\n");
    return -1;
  }

  end->l = end;
  end->r = end;
  end->name = "";
  end->data = NULL;
  end->red = 0;

  base = malloc(sizeof *base);
  if (base == NULL) {
    fprintf(stderr, "Can't setup list data\n");
    return -1;
  }

  base->l = end;
  base->r = end;
  base->name = "";
  base->data = NULL;
  base->red = 0;

  return 0;
}

/* Rotate (add sub) */
static struct node *
rotate(char *name, struct node *y)
{
  struct node *c, *gc;

#ifdef DEBUG
  printf("rotate: %s about %s\n", name, y->name);
#endif

  c = (strcmp(name, y->name) < 0) ? y->l : y->r;
  if (strcmp(name, c->name) < 0) {
    gc = c->l;
    c->l = gc->r;
    gc->r = c;
  } else {
    gc = c->r;
    c->r = gc->l;
    gc->l = c;
  }
  if (strcmp(name, y->name) < 0)
    y->l = gc;
  else
    y->r = gc;
  return gc;
}

static void
split(char *name)
{
  x->red = 1;
  x->l->red = 0;
  x->r->red = 0;
  if (p->red) {
    g->red = 1;
    if ((strcmp(name, g->name) < 0) != (strcmp(name, p->name) < 0))
      p = rotate(name, g);
    x = rotate(name, gg);
    x->red = 0;
  }
  base->r->red = 0;
}

/* Add a career to our table */
int
add_career(struct node *data)
{
  if (!data)
    return -1;

#ifdef DEBUG
  printf("Adding %s\n", data->name);
#endif

  /* Start at the beginning */
  x = base;
  p = base;  /* Parent */
  g = base;  /* Grandparent */
  gg = base; /* Great gradparent */

  /* Find the space */
  while (x != end) {
    gg = g;
    g = p;
    p = x;
    x = (strcmp(data->name, x->name) < 0) ? x->l : x->r;
    if (x->l->red && x->r->red)
      split(data->name);
  }

  /* Add */
  x = data;
  data->l = end;
  data->r = end;
  if (strcmp(data->name, p->name) < 0) {
#ifdef DEBUG
    printf("to the left of %s\n", p->name);
#endif
    p->l = data;
  } else {
#ifdef DEBUG
    printf("to the right of %s\n", p->name);
#endif
    p->r = data;
  }

  split(data->name);

  return 0;
}

struct career *
career_info(char *name)
{
  struct node *p = base->r;
  int i;

  /* Abort on.. */
  end->name = name;

  /* Find the node */
  while ((i = strcmp(name, p->name)) != 0)
    p = (i < 0) ? p->l : p->r;

  /* Or did we? */
  if (p == end)
    return NULL;

  /* Load the data if we don't have it already */
  if (p->data == NULL)
    load_career(p);

  return p->data;
}

#ifdef DEBUG
static int depth, curdepth;
#endif

void
sub_each_career(void (*function)(struct career *), struct node *node)
{
#ifdef DEBUG
  curdepth++;
  if (depth < curdepth)
    depth = curdepth;
#endif

  if (node->l != end)
    sub_each_career(function, node->l);

  /* Delayed loading */
  if (node->data == NULL)
    load_career(node);

  function(node->data);

  if (node->r != end)
    sub_each_career(function, node->r);

#ifdef DEBUG
  curdepth--;
#endif
}

/* For each career... */
void
each_career(void (*function)(struct career *))
{
#ifdef DEBUG
  depth = 0;
  curdepth = 0;
#endif

  sub_each_career(function, base->r);

#ifdef DEBUG
  printf("depth: %i\n", depth);
#endif
}


/******************************* DISK I/O ********************************/
  
/* Read a profile string into the career */
void
parse_profile(char *str, struct career *dest)
{
  int i;
  i = sscanf(str, "%u %u %u %u %u %u %u %u %u %u %u %u %u %u",
	     &(dest->advance.M), &(dest->advance.WS), &(dest->advance.BS),
	     &(dest->advance.S), &(dest->advance.T), &(dest->advance.W),
	     &(dest->advance.I), &(dest->advance.A), &(dest->advance.Dex),
	     &(dest->advance.Ld), &(dest->advance.Int), &(dest->advance.Cl),
	     &(dest->advance.WP), &(dest->advance.Fel));

  if (i != 14) {
    fprintf(stderr, "Bad profile for %s\n", dest->name);
  }
}

int
parse_skill(const char *s, struct career *dest)
{
  unsigned int prob = 0;

  while (isdigit(*s)) {
    prob = prob * 10 + (int)(*s - '0');
    s++;
  }

  /* Skip space */
  s++;

  if (strchr(s, '\n') != NULL)
    *strchr(s, '\n') = '\0';
  
  if (add_string(s, prob, &(dest->skills)) == -1)
    return -1;
  else
    return 0;
}

void
do_equiv(char *buf, struct node *p)
{
  fpos_t save_loc;
  struct career *tmp;
  struct string *str;

#ifdef DEBUG
  str = p->data->exits;
  while (str != NULL) {
    printf("chk: %s -> %s\n", p->data->name, str->name);
    str = str->next;
  }
#endif
  
  if (strchr(buf, '\n'))
    *strchr(buf, '\n') = '\0';
  
  /* Save location */
  if (fgetpos(db, &(save_loc)) != 0) {
    perror("Can't save career location!");
    return;
  }
  
  tmp = career_info(&(buf[1]));
  if (tmp == NULL) {
    fprintf(stderr, "Unable to equate %s and %s\n", p->name, &(buf[1]));
    return;
  }

  /* Go back to the appropriate point in the db */
  if (fsetpos(db, &(save_loc)) != 0) {
    perror("Can't restore career location!");
    return;
  }

  /* Add equivalence */
  p->data->equiv = tmp->name;

  /* Make sure it doesn't propogate */
  if (add_string((p->name), 100, &(tmp->no_equiv)) == -1)
    fprintf(stderr, "Unable to equate %s and %s\n", p->name, &(buf[1]));

  /* Copy data */
  memcpy(&(p->data->advance), &(tmp->advance), sizeof (tmp->advance));
  str = tmp->skills;
  while (str != NULL) {
    add_string(str->name, str->chance, &(p->data->skills));
#ifdef DEBUG
    printf("equiv: %s skill %s to %s\n", tmp->name, str->name, p->name);
#endif
    str = str->next;
  }

  str = tmp->exits;
  while (str != NULL) {
    if (add_string(str->name, str->chance, &(p->data->exits)) == -1)
#ifdef DEBUG
      printf("equiv: %s exit %s to %s\n", tmp->name, str->name, p->name);
#endif
    str = str->next;
  }

  str = tmp->entrys;
  while (str != NULL) {
    add_string(str->name, str->chance, &(p->data->entrys));
#ifdef DEBUG
    printf("equiv: %s entry %s to %s\n", tmp->name, str->name, p->name);
#endif
    str = str->next;
  }

#ifdef DEBUG
  str = p->data->exits;
  while (str != NULL) {
    printf("chk2: %s -> %s\n", p->data->name, str->name);
    str = str->next;
  }
#endif
}

void
load_career(struct node *p)
{
  char buf[BUF_SIZ];

#ifdef DEBUG
  printf("load: %s\n", p->name);
#endif

  /* Go to the appropriate point in the db */
  if (fsetpos(db, &(p->location)) != 0) {
    perror("Can't go to career location!");
    return;
  }

  /* Allocate space */
  p->data = malloc(sizeof(struct career));
  if (p->data == NULL)
    return;

  /* Setup */
  p->data->name = p->name;
  p->data->skills = NULL;
  p->data->exits = NULL;
  p->data->entrys = NULL;
  p->data->equiv = NULL;
  if (add_string(p->name, 100, &(p->data->no_equiv)) != 0)
      fprintf(stderr, "Self non-equivalence failed in %s\n", p->name);

  /* Read & parse */
  while ((fgets(buf, BUF_SIZ, db) != NULL) && (buf[0] != '!')) {
    switch (buf[0]) {
    case 'P':
      parse_profile(&(buf[1]), p->data);
      break;
    case 'S':
      parse_skill(&(buf[1]), p->data);
      break;
    case 'E':
      if (strchr(buf, '\n'))
	*strchr(buf, '\n') = '\0';
      if (add_string(&(buf[1]), 100, &(p->data->exits)) == -1)
	fprintf(stderr, "Unable to add exit %s to %s\n", &(buf[1]), p->name);
      break;
    case 'F':
      if (strchr(buf, '\n'))
	*strchr(buf, '\n') = '\0';
      if (add_string(&(buf[1]), 100, &(p->data->entrys)) == -1)
	fprintf(stderr, "Unable to add entry %s to %s\n", &(buf[1]), p->name);
      break;
    case 'Q':
      do_equiv(buf, p);
      break;      
    }
  }
}

/* BUG:  Link career functions don't work on careers with
         equivalences properly, instead going over the list twice
	 - which is grossly inefficent
   */

void
sub_link_career_db(struct career *p)
{
  struct career *target;
  struct string *list;
  
  /* Add to all entries */
  list = p->entrys;
  while (list != NULL) {
    target = career_info(list->name);
    if (target != NULL && in_string_list(target->no_equiv, p->name) == 0) {
#ifdef DEBUG
      printf("link: %s exits to %s\n", p->name, target->name);
#endif
      add_string(p->name, 100, &(target->exits));
    }
    list = list->next;
  }

  /* And all exits */
  list = p->exits;
  while (list != NULL) {
    target = career_info(list->name);
    if (target != NULL && in_string_list(target->no_equiv, p->name) == 0) {
#ifdef DEBUG
      printf("link: %s enters %s\n", p->name, target->name);
#endif
      add_string(p->name, 100, &(target->entrys));
    }
    list = list->next;
  }  
}

/* Goes through the database and cross-references everything */
void
link_career_db()
{
  each_career(sub_link_career_db);
  each_career(sub_link_career_db);
}
  

int
init_career_db(void)
{
  char buf[BUF_SIZ];
  struct node *tmp = NULL;

  db = fopen(DB_NAME, "r");
  if (db == NULL) {
    perror("Couldn't open career database");
    return -1;
  }

  if (init_tree() == -1) {
    return -1;
  }

  /* Read the file */
  while (fgets(buf, BUF_SIZ, db)) {
    if (buf[0] == '!') {
      /* We've got a new career */
      if (tmp)
	add_career(tmp);

      /* This test is probably paranoid & wasteful. Still */
      if (strchr(buf, '\n'))
	*strchr(buf, '\n') = '\0';

      tmp = malloc(sizeof(struct node));
      if (tmp == NULL) {
	fprintf(stderr, "Out of memory!\n");
	return -1;
      }
      /* Fill in the name */
      tmp->name = malloc(strlen(buf));
      if (tmp->name == NULL) {
	fprintf(stderr, "Out of memory!\n");
	return -1;
      }
      strcpy(tmp->name, &(buf[1]));

      tmp->data = NULL;
      if (fgetpos(db, &(tmp->location)) != 0) {
	perror("Can't store file location ");
	return -1;
      }
    }
  }

  /* Add the last career */
  if (tmp)
    add_career(tmp);

  return 0;
}
