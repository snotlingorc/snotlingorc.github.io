/* Make s all lower case */
void
mk_lower(char *s);

/* Seed the random number generator portably */
void randomize(void);
