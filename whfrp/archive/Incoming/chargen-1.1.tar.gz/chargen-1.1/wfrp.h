#ifndef _WFRP_H
#define _WFRP_H

/* Character generation back end */

/* Basic stats */
struct profile {
  unsigned int M, WS, BS, S, T, W, I, A, Dex, Ld, Int, Cl, WP, Fel;
};

/* Skills (linked list) */
struct string {
  char *name;
  unsigned int chance;
  struct string *next;
};

/* THE structure :-) */
struct pc {
  struct profile basic;
  unsigned int race, sex, class, fate, mp, skill_c;
  unsigned int age, height;  /* Height in inches */
  char *career;
  struct string *skills;
};

/* Generic 'undefined' constant */
#define UNDEF 0

#define RACE_HUMAN 1
#define RACE_ELF 2
#define RACE_DWARF 4
#define RACE_HALFLING 8
#define RACE_GNOME 16

#define SEX_MALE 1
#define SEX_FEMALE 2

#define AGE_YOUNG 1
#define AGE_OLD 2

#define CLASS_WARRIOR 1
#define CLASS_RANGER 2
#define CLASS_ROGUE 4
#define CLASS_ACADEMIC 8

/* Race filename prefixes */
#define FN_HUMAN "hu"
#define FN_ELF "el"
#define FN_DWARF "dw"
#define FN_HALFLING "hl"
#define FN_GNOME "gn"
#define F_RACE 2

/* Class prefixes */
#define FN_WARRIOR "w"
#define FN_RANGER "r"
#define FN_ROGUE "o"
#define FN_ACADEMIC "a"
#define F_CLASS 1

/* Types of file */
#define FN_PROFILE "prof"
#define FN_BASIC "base"
#define FN_SKILL "skill"
#define FN_CAREER "car"

#define FN_LEN 10

/* Generate basic stats */
struct pc
gen_stats(unsigned int race, unsigned int sex, unsigned int age);

/* Do class-specific generation */
void
gen_class(struct pc *character);

/* Add a skill uniquely to a list of skills */
int
add_string(const char *name, unsigned int chance, struct string **node);

/* Add skills from src to dest probabilisticly */
void
prob_add_strings(struct string *src, struct string **dest);

/* Delete a list of strings */
void
delete_strings(struct string *target);

/* Is s in the list list? */
int
in_string_list(const struct string *list, const char *s);

#endif
