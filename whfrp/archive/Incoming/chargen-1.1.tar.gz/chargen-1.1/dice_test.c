#include <stdio.h>
#include "dice.h"

int
main(void)
{
  int i;
  
  for (i=0; i < 200; i++) {
    printf("%i\n", d(10, 100));
  }

  ndn_str("2D6+2");
  ndn_str("30D300-2");
  ndn_str("This had better give me an error value...\n");

  return 0;
}
