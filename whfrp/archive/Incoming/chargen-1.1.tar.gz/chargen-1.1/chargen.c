/* Command line character generator */

#ifdef HAVE_CONFIG_H
#include "config.h"
#else
#define HAVE_CHDIR
#endif

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <time.h>
#include <locale.h>

#ifdef HAVE_CHDIR
#include <unistd.h>
#endif

#include "wfrp.h"
#include "career.h"
#include "util.h"

/* Eat all characters up to next \n */
void
eatline(FILE *fp)
{
  int c;

  while ((c = fgetc(fp)) != '\n' && c != EOF)
    ;
}

void
print_profile(struct pc character)
{
  printf("M   WS  BS  S   T   W   I   A   Dex Ld  Int Cl  WP  Fel\n");
  printf("%-3u %-3u %-3u %-3u %-3u %-3u %-3u %-3u %-3u %-3u %-3u %-3u %-3u %-3u\n",
	 character.basic.M, character.basic.WS, character.basic.BS, character.basic.S,
	 character.basic.T, character.basic.W, character.basic.I, character.basic.A,
	 character.basic.Dex, character.basic.Ld, character.basic.Int, character.basic.Cl,
	 character.basic.WP, character.basic.Fel);
}

void
print_advance(struct career *car)
{
  printf("%-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u %-+3u\n",
	 car->advance.M, car->advance.WS, car->advance.BS, car->advance.S,
	 car->advance.T, car->advance.W, car->advance.I, car->advance.A,
	 car->advance.Dex, car->advance.Ld, car->advance.Int, car->advance.Cl,
	 car->advance.WP, car->advance.Fel);
}


void
print_skills(struct pc character)
{
  struct string *node = character.skills;

  printf("Skills:\n");
  while (node) {
    printf("\t%s\n", node->name);
    node = node->next;
  }
}

void
print_exits(struct career *car)
{
  struct string *node = car->exits;

  printf("Exits:\n");
  while (node) {
    printf("\t%s\n", node->name);
    node = node->next;
  }
}


int 
main(void)
{
  unsigned int age = UNDEF;
  unsigned int race = UNDEF;
  unsigned int sex = UNDEF;
  int c;
  struct pc character;
  struct career *career;

  /* Enforce users locale choices */
  (void)setlocale (LC_ALL, "");
  
  (void)puts("chargen - Copyright (C) UK 1997 by Mark Brown\n");

  /* Go where the data files are */
#ifdef HAVE_CHDIR
  if (chdir(LIB_DIR) != 0) {
    perror("Couldn't chdir to " LIB_DIR);
  }
#endif

  randomize();
  
  while (race == UNDEF) {
    (void)puts("Which race - (H)uman/(E)lf/(D)warf/Ha(l)fling/(G)nome?");

    if ((c = getchar()) == EOF) {
      fprintf(stderr, "EOF in input");
      exit(EXIT_FAILURE);
    }
    switch (tolower(c)) {
    case 'h':
      race = RACE_HUMAN;
      break;
    case 'e':
      race = RACE_ELF;
      break;
    case 'd':
      race = RACE_DWARF;
      break;
    case 'l':
      race = RACE_HALFLING;
      break;
    case 'g':
      race = RACE_GNOME;
      break;
    }

    if (c != '\n')
      eatline(stdin);
  }

  while (sex == UNDEF) {
    (void)puts("What sex - (M)ale/(F)emale?");

    if ((c = getchar()) == EOF) {
      fprintf(stderr, "EOF in input");
      exit(EXIT_FAILURE);
    }

    switch (tolower(c)) {
    case 'm':
      sex = SEX_MALE;
      break;
    case 'f':
      sex = SEX_FEMALE;
      break;
    }

    if (c != '\n')
      eatline(stdin);
  }
  
  while (age == UNDEF) {
    (void)puts("How old - (Y)oung/(O)ld?");

    if ((c = getchar()) == EOF) {
      fprintf(stderr, "EOF in input");
      exit(EXIT_FAILURE);
    }

    switch (tolower(c)) {
    case 'y':
      age = AGE_YOUNG;
      break;
    case 'o':
      age = AGE_OLD;
      break;
    }

    if (c != '\n')
      eatline(stdin);
  }

  character = gen_stats(race, sex, age);

  print_profile(character);
  printf("\nFate: %u\tHeight: %i\'%u\"\tAge: %u\n",  character.fate,
	 character.height / 12,  character.height % 12,  character.age);
  if (character.skills)
    print_skills(character);

  /* Now let's choose some more */
  (void)putchar('\n');

  if (!character.class) {
    printf("This character doesn't make the grade for any class\n");
    exit(EXIT_FAILURE);
  }

  /* Only ask about class if we have a choice */
  if (character.class != CLASS_WARRIOR &&
      character.class != CLASS_RANGER &&
      character.class != CLASS_ROGUE &&
      character.class != CLASS_ACADEMIC) {
    age = UNDEF;
    while (age == UNDEF) {
      printf("Class - ");
      if (character.class & CLASS_WARRIOR)
	printf("(W)arrior/");
      if (character.class & CLASS_RANGER)
	printf("(R)anger/");
      if (character.class & CLASS_ROGUE)
	printf("R(o)gue/");
      if (character.class & CLASS_ACADEMIC)
	printf("(A)cademic/");
      printf("\b?\n");
      
      if ((c = getchar()) == EOF) {
	fprintf(stderr, "EOF in input");
	exit(EXIT_FAILURE);
      }
      
      switch (tolower(c)) {
      case 'w':
	if (character.class & CLASS_WARRIOR)
	  age = CLASS_WARRIOR;
	break;
      case 'r':
	if (character.class & CLASS_RANGER)
	  age = CLASS_RANGER;
	break;
      case 'o':
	if (character.class & CLASS_ROGUE)
	  age = CLASS_ROGUE;
	break;
      case 'a':
	if (character.class & CLASS_ACADEMIC)
	  age = CLASS_ACADEMIC;
	break;
      }
      
      if (c != '\n')
	eatline(stdin);
    }
    
    character.class = age;
  } else {
    age = character.class;

    printf("This character must be a ");
    switch (character.class) {
    case CLASS_WARRIOR:
      (void)puts("Warrior");
      break;
    case CLASS_RANGER:
      (void)puts("Ranger");
      break;
    case CLASS_ROGUE:
      (void)puts("Rogue");
      break;
    case CLASS_ACADEMIC:
      (void)puts("Academic");
      break;
    }
  }

  /* Init the career database */
  if (init_career_db() != 0) {
    fprintf(stderr, "Couldn't initialize the career database\n");
    exit(EXIT_FAILURE);
  }

  link_career_db();

  gen_class(&character);

  career = career_info(character.career);
  if (career)
    prob_add_strings(career->skills, &(character.skills));

  /* Do our stuff again */
  print_profile(character);
  if (career)
    print_advance(career);
  printf("\nFate: %u\tHeight: %i\'%i\"\tAge: %u\n",  character.fate,
	 character.height / 12,  character.height % 12,  character.age);
  print_skills(character);

  printf("Career: %s\n", character.career);

  if (career)
    print_exits(career);

  return 0;
}
