/* Career database stuff */
#include "wfrp.h"

struct career {
  char *name;
  struct profile advance;
  struct string *skills;
  struct string *entrys, *exits;  /* Silly name for exits, but it works */
  char *equiv;
  struct string *no_equiv;
  char *mp;
};

/* Database name */
#define DB_NAME "career"

/* Initialize the career database - -1 on error */
int
init_career_db(void);

/* Make forward and backward links in database - loads everything into
   core at present, so might not be a Good Thing on some platforms */
void
link_career_db(void);

/* Return info on career with given name */
/*@null@*/ struct career *
career_info(char *name);

/* For each career... */
void
each_career(void (*function)(struct career *));
