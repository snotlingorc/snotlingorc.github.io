#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include <limits.h>

#include "wfrp.h"
#include "dice.h"
#include "career.h"
#include "util.h"

#define BUF_SIZ 1024
#define SMALL_SIZ 50

/* 	$Id: wfrp.c,v 1.3 1997/09/03 14:47:30 broonie Exp $	 */

#ifndef lint
static char vcid[] = "$Id: wfrp.c,v 1.3 1997/09/03 14:47:30 broonie Exp $";
#endif /* lint */


/* Race-skill */
void
basic_skill(struct pc *player, char *buf, char *filename, int line)
{
  char small_buf[SMALL_SIZ], small_buf2[SMALL_SIZ];
  unsigned int n;
  if (player->skill_c) {   /* Slots? */
    if (sscanf(buf, "%c %u %s", small_buf2, &n, small_buf) != 3) {
      fprintf(stderr, "%s:%i: bad default skill line\n", filename, line);
      return;
    } else {
      char *s;
      
      /* Take the nth skill */
      n = d(1, n);
      
      s = strtok(buf, "$");
      if (s != NULL) 
	while (n && ((s = strtok(NULL, "$")) != NULL)) {
	  n--;
	}

      /* And try and add it */
      if (!add_string(s, 100, &(player->skills)))
	(player->skill_c)--;
    }
  }	
}

void
class_skill(char *filename, struct pc *player)
{
  FILE *fp;
  int line = 0;
  char buf[BUF_SIZ];
  unsigned int roll, min, max;

  strcat(filename, FN_SKILL);

  /* OK, open skills list */
  if (!(fp = fopen(filename, "r"))) {
    sprintf(buf, "Unable to open file %s", filename);
    perror(buf);
    exit(EXIT_FAILURE);
  }

  /* While there are skills to allocate */
  while (player->skill_c) {
    /* Roll the dice */
    roll = d(1, 100);
    
    while (fgets(buf, BUF_SIZ, fp) != NULL) {
      line++;
      
#ifdef DEBUG
      printf("%s:%i: %s", filename, line, buf);
#endif
      if (buf[0] != '#' && buf[0] != '\n') {	
	if (!(sscanf(buf, "%u %u", &min, &max) == 2)) {
	fprintf(stderr, "%s:%i: parse error\n", filename, line);
	}
	
	if (min <= roll && roll <= max) {
	  int i;
	  char *s = buf;
	  
	  /* Eat the first two lots of whitespace */
	  for (i = 0; i < 2; i++) {
	    /* Find blank space */
	    while (*s != ' ' && *s != '\t')
	      s++;
	    /* Skip space */
	    do {
	      s++;	    
	    } while (*(s + 1) == ' ' || *(s + 1) == '\t');
	  }
	  
	  s[strlen(s)-1] = '\0';	  

	  /* Now try and add */
	  if (add_string(s, 100, &(player->skills)) == 0)
	    player->skill_c -= 1;
	  
	  /* Get out of loop */
	  break;
	}
      }
    }
    
    /* And go back to the beginning */
    if (fseek(fp, 0, SEEK_SET) != 0)
      perror("Unable to seek to start of career database");
    line = 0;
  }

  (void)fclose(fp);
}

/* Pick a career if the career is one with multiple equivalences */
void
select_equiv(struct pc *player)
{
  struct career *data;
  struct string *p;
  unsigned int i = 0;

  /* Get the record */
  data = career_info(player->career);
  if (data == NULL)  /* Sanity */
    return;

  /* Get the length of the careers equivalent list */
  p = data->no_equiv;
  while (p) {
    p = p->next;
    i++;
  }

  /* Do we need to do anything? */
  if (i <= 1)
    return;

  /* We won't be needing the current career name anymore */
  free(player->career);

  /* Select 1 (but not the last entry, which is the career itself) */
  i = d(1, i - 1);

  /* Get the name */
  p = data->no_equiv;
  while (--i)
    p = p->next;

  /* And make it our new career name */
  player->career = p->name;
}

/* Player career */
void
class_career(char *filename, struct pc *player)
{
  FILE *fp;
  int line = 0;
  char buf[BUF_SIZ];
  unsigned int roll, min, max;

  strcat(filename, FN_CAREER);
  roll = d(1, 100);
  
  /* Open data file */
  fp = fopen(filename, "r");
  if (!fp) {
    sprintf(buf, "Unable to open %s", filename);
    perror(buf);
    exit(EXIT_FAILURE);
  }

  while (fgets(buf, BUF_SIZ, fp) != NULL) {
    line++;
    
#ifdef DEBUG
    printf("%s:%i: %s", filename, line, buf);
#endif
    if (buf[0] != '#' && buf[0] != '\n') {	
      if (!(sscanf(buf, "%u %u", &min, &max) == 2)) {
	fprintf(stderr, "%s:%i: parse error\n", filename, line);
      }
	
      if (min <= roll && roll <= max) {
	int i;
	char *s = buf;
	  
	/* Eat the first two lots of whitespace */
	for (i = 0; i < 2; i++) {
	  /* Find blank space */
	  while (*s != ' ' && *s != '\t')
	    s++;
	  /* Skip space */
	  do {
	    s++;	    
	  } while (*(s + 1) == ' ' || *(s + 1) == '\t');
	}
	
	s[strlen(s)-1] = '\0';	  
	
	/* Gotcha */
	if (!(player->career = malloc(strlen(s) + 1))) {
	  fprintf(stderr, "Unable to allocate space for career\n");
	  exit(EXIT_FAILURE);
	}
	strcpy(player->career, s);

	/* Get out of loop */
	break;	
      }
    }
  }

  (void)fclose(fp);

  /* And handle multi-way careeers */
  select_equiv(player);
}

/* Stats generation entry */
struct pc
gen_stats(unsigned int race, unsigned int sex, unsigned int age)
{
  struct pc player;
  FILE *fp;
  char filename[FN_LEN];
  char buf[BUF_SIZ];
  int line = 0;
  unsigned int random = UINT_MAX;

  char small_buf[SMALL_SIZ], small_buf2[SMALL_SIZ];
  unsigned int n, sides, con, *target;

  /* We know this already (defaults) */
  player.race = race;
  player.sex = sex;
  player.mp = 0;
  player.class = (unsigned)(CLASS_WARRIOR + CLASS_RANGER + CLASS_ROGUE + CLASS_ACADEMIC);
  player.skills = NULL;

  /* Select race indicator */
  switch (race) {
  case RACE_HUMAN:
    strcpy(filename, FN_HUMAN);
    break;
  case RACE_ELF:
    strcpy(filename, FN_ELF);
    break;
  case RACE_DWARF:
    strcpy(filename, FN_DWARF);
    break;
  case RACE_HALFLING:
    strcpy(filename, FN_HALFLING);
    break;
  case RACE_GNOME:
    strcpy(filename, FN_GNOME);
    break;
  }

  /* Add on tpye */
  strcat(filename, FN_PROFILE);

  /* Open data file */
  fp = fopen(filename, "r");
  if (!fp) {
    fprintf(stderr, "Unable to open %s\n", filename);
    exit(EXIT_FAILURE);
  }

  /* Read the file */
  while (fgets(buf, BUF_SIZ, fp)) {
    line++;

#ifdef DEBUG
    printf("%s:%i: %s", filename, line, buf);
#endif

    /* Skip empty/comment lines */
    if (buf[0] != '#' && buf[0] != '\n') {
      /* Parse the line */
      if (sscanf(buf, "%s %u %u %u", small_buf, &n, &sides, &con) != 4) {
	fprintf(stderr, "%s:%i: parse error\n", filename, line);
      } else {
	/* Force case */
	mk_lower(small_buf);

	/* Work out which field we're dealing with */
	if (!strcmp(small_buf, "m")) {
	  target = &(player.basic.M);	  
	} else if (!strcmp(small_buf, "ws")) {
	  target = &(player.basic.WS);
	} else if (!strcmp(small_buf, "bs")) {
	  target = &(player.basic.BS);
	} else if (!strcmp(small_buf, "s")) {
	  target = &(player.basic.S);
	} else if (!strcmp(small_buf, "t")) {
	  target = &(player.basic.T);
	} else if (!strcmp(small_buf, "w")) {
	  target = &(player.basic.W);
	} else if (!strcmp(small_buf, "i")) {
	  target = &(player.basic.I);
	} else if (!strcmp(small_buf, "a")) {
	  target = &(player.basic.A);
	} else if (!strcmp(small_buf, "dex")) {
	  target = &(player.basic.Dex);
	} else if (!strcmp(small_buf, "ld")) {
	  target = &(player.basic.Ld);
	} else if (!strcmp(small_buf, "int")) {
	  target = &(player.basic.Int);
	} else if (!strcmp(small_buf, "cl")) {
	  target = &(player.basic.Cl);
	} else if (!strcmp(small_buf, "wp")) {
	  target = &(player.basic.WP);
	} else if (!strcmp(small_buf, "fel")) {
	  target = &(player.basic.Fel);
	} else if (!strcmp(small_buf, "fate")) {
	  target = &(player.fate);
	} else if (!strcmp(small_buf, "skills")) {
	  target = &(player.skill_c);
	} else if (!strcmp(small_buf, "age_young")) {
	  if (age == AGE_YOUNG) {
	    /* Since ages have minima, we need a Special Case */
	    player.age = 0;
	    while (player.age < 16)
	      player.age += d(n, sides) + con;
	  }
	  target = &n;
	} else if (!strcmp(small_buf, "age_old")) {
	  if (age == AGE_OLD) {
	    /* Since ages have minima, we need a Special Case */
	    player.age = 0;
	    while (player.age < 16)
	      player.age += d(n, sides) + con;
	  }
	  target = &n;
	} else if (!strcmp(small_buf, "height_male")) {
	  if (player.sex == SEX_MALE)
	    target = &(player.height);
	  else
	    target = &n;
	} else if (!strcmp(small_buf, "height_female")) {
	  if (player.sex == SEX_FEMALE)
	    target = &(player.height);
	  else
	    target = &n;
	} else {
	  /* Do nothing */
	  target = &n;
	  
	  /* But warn about it */
	  fprintf(stderr, "%s:%i: unknown stat\n", filename, line);	  
	}

	/* Put the data there */
	*target = d(n, sides) + con;
      }      
    }
  }

  /* Close the data file */
  (void)fclose(fp);

  /* Other info (should be in one file) */
  filename[F_RACE] = '\0';
  line = 0;
  strcat(filename, FN_BASIC);

  /* Open data file */
  fp = fopen(filename, "r");
  if (!fp) {
    sprintf(buf, "Unable to open %s\n", filename);
    perror(buf);
    exit(EXIT_FAILURE);
  }

  /* Read the file */
  while (fgets(buf, BUF_SIZ, fp)) {
    line++;
    n = 0;

#ifdef DEBUG
    printf("%s:%i: %s", filename, line, buf);
#endif

    /* Skip empty/comment lines */
    if (buf[0] != '#' && buf[0] != '\n') {
      switch (toupper(buf[0])) {
	/* Class restrictions */
      case 'W':
      case 'G':
      case 'R':
      case 'A':
	if (sscanf(buf, "%c %s %u", small_buf2, small_buf, &n) != 3)
	  fprintf(stderr, "%s:%i: bad class restriction\n", filename, line);
	else {
	  mk_lower(small_buf);

	  target = &random;
	  
	  if (!strcmp(small_buf, "m")) {
	    target = &(player.basic.M);	  
	  } else if (!strcmp(small_buf, "ws")) {
	    target = &(player.basic.WS);
	  } else if (!strcmp(small_buf, "bs")) {
	    target = &(player.basic.BS);
	  } else if (!strcmp(small_buf, "s")) {
	    target = &(player.basic.S);
	  } else if (!strcmp(small_buf, "t")) {
	    target = &(player.basic.T);
	  } else if (!strcmp(small_buf, "w")) {
	    target = &(player.basic.W);
	  } else if (!strcmp(small_buf, "i")) {
	    target = &(player.basic.I);
	  } else if (!strcmp(small_buf, "a")) {
	    target = &(player.basic.A);
	  } else if (!strcmp(small_buf, "dex")) {
	    target = &(player.basic.Dex);
	  } else if (!strcmp(small_buf, "ld")) {
	    target = &(player.basic.Ld);
	  } else if (!strcmp(small_buf, "int")) {
	    target = &(player.basic.Int);
	  } else if (!strcmp(small_buf, "cl")) {
	    target = &(player.basic.Cl);
	  } else if (!strcmp(small_buf, "wp")) {
	    target = &(player.basic.WP);
	  } else if (!strcmp(small_buf, "fel")) {
	    target = &(player.basic.Fel);
	  } else {
	    fprintf(stderr, "%s:%i: bad class restriction", filename, line);
	    break;
	  }

	  if (*target < n) {
	    switch (toupper(buf[0])) {
	    case 'W':
	      player.class -= CLASS_WARRIOR & player.class;
	    break;
	    case 'G':
	      player.class -= CLASS_RANGER & player.class;
	      break;
	    case 'R':
	      player.class -= CLASS_ROGUE & player.class;
	      break;
	    case 'A':
	      player.class -= CLASS_ACADEMIC & player.class;
	      break;
	    }
	  }
	}
	  
	break;
      case 'S':
	/* Skills modifier */
	if (sscanf(buf, "%c %u %u %u", small_buf, &n, &sides, &con) != 4)
	  fprintf(stderr, "%s:%i: bad skill modifier\n", filename, line);
	else if (player.age >= n && player.age <= sides) {
	  player.skill_c += con;
	  /* Can't be less than zero */
	  if (player.skill_c < 0)
	    player.skill_c = 0;
	}
	break;

      case 'K':
	basic_skill(&player, buf, filename, line);
	break;
	
      default:
	fprintf(stderr, "%s:%i: parse error\n", filename, line);
      }
    }
  }

  /* Close file */
  (void)fclose(fp);

  /* fix fate points */
  if (player.fate == 0)
    player.fate = 1;
  
  return player;
}

/* Do class-specific generation */
void
gen_class(struct pc *player)
{
  char filename[FN_LEN];
  
  switch (player->race) {
  case RACE_HUMAN:
    strcpy(filename, FN_HUMAN);
    break;
  case RACE_ELF:
    strcpy(filename, FN_ELF);
    break;
  case RACE_DWARF:
    strcpy(filename, FN_DWARF);
    break;
  case RACE_HALFLING:
    strcpy(filename, FN_HALFLING);
    break;
  case RACE_GNOME:
    strcpy(filename, FN_GNOME);
    break;
  }

  switch (player->class) {
  case CLASS_WARRIOR:
    strcat(filename, FN_WARRIOR);
    break;
  case CLASS_RANGER:
    strcat(filename, FN_RANGER);
    break;
  case CLASS_ROGUE:
    strcat(filename, FN_ROGUE);
    break;
  case CLASS_ACADEMIC:
    strcat(filename, FN_ACADEMIC);
    break;
  }

  /* Do the skills */
  class_skill(filename, player);

  /* And now, a career... */
  filename[F_RACE + F_CLASS] = '\0';  /* Get back filename */
  class_career(filename, player);
}
