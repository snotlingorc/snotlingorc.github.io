WarcFix.zip - This file fixes the installation problems with warcgen.zip.

Instructions:  Unzip WARCGEN.ZIP to a temporary directory.
	       Unzip WARCFIX.ZIP to the same directory, overwriting the existing files.
               Run SETUP.EXE

The problem:   WARCGEN.ZIP contains three files from the Windows '95 beta OS.  These are
               incompatible with any lower version number of windows.  The fix is to
               replace these files with the versions from WFWG 3.11.  The lowest version
               of windows I have access to.  Installation will now work correctly on
               any version of windows 3.1 or higher.

Note:          Installation only tested on WFWG 3.11 and Windows '95 Build 490.


If you have any further problems, please contact me.

Randy N. Carlson
carlsonr@bighorn.accessnv.com
