Warhammer Fantasy Roleplay Character Generator v0.9  (Win95)


Contents
--------

   1. Main Features
   2. Instalation
   3. Using the Program
   4. Notes on the program working
   5. Data Files
   6. Future Enhancements
   7. Copyrights
   8. Disclaimer
   9. Registration
  10. Source Code



1. Main Features
----------------

   The program is capable of creating a character and his/her initial
   career. It also allows for the character to advance through other 
   careers. All choices concerning race, career-class, initial career 
   and later career advancements can be made on a random basis, or can 
   be hand-picked. 
   
   The program will keep track of the relevant stats (characteristics,
   age, magick points, fate points), skills and trappings.
   
   In addition each character will be given a name, using a name-
   generator which was largely based on the tables in the Character
   Pack.

 
2. Instalation
--------------

   Just unzip all the files in a directory of your choice and run
   WFRPCHAR.EXE.
  

3. Using the Program
--------------------

   I think the program use is fairly straight forward.

   Click the 'New Character'-button to create a character. You can
   manually pick a Race and Career, or have the program do this 
   on a random basis.
         
   Click the 'Advance Character'-button to advance the character to
   his/her next career, either a Career Exit of the current career
   or a New Basic Career.

   You can save the character (ASCII-file) using the file-menu.
   
   The Options menu allows you to set some options (obviously). These
   are the following:
    * Complete Initial Career
        When this option is checked, the character will take all 
        advances associated with the initial career, as well as
        learning the percentage skills which were failed.
        When the option is not checked, all non-percentage skills 
        will be learned, as well as the percentage skills for which
        a successful test was made. A character created this way can
        not advance to another career.
        Normally this option will be unchecked when generating PC's, 
        while it should be checked to generate NPC's.
    * Aging
        When this option is checked, the character's age will
        increase with 4 years, for each career the character is 
        involved in. (Thus making it rather hard to create a Level 4
        Necromancer, aged 17)
    * Starter Trappings
        With this option checked, the program will generate a starter
        set of trappings for adventurers (PC's), based on the Career
        Class of the character.
        Normally this option will only be checked for generating PC's,
        but you might want to check it when generating NPC's as well.
        With the option unchecked, the character will also miss out on
        the adventurer starting capital of 3D6 Gold Crowns.
    * Keep Trappings
        When this option is checked, the character will keep his current
        trappings when advancing to a next career.
        This option only has influence on the career-bound trappings. It
        has no influence on the Starter Trappings, which will always be
        kept (if generated, see option above).


4. Notes on the program working
-------------------------------

   Racial stats are as mentioned in the rulebook, with 1 exception: 
   for elves WS = 2D10 + 20 and BS = 2D10 + 30 (the rulebook states
   this the other way round, but our gaming group prefers it this
   way).

   Random computer chosen careers are in line with the rulebook racial
   restrictions; if you pick Career and Race yourself, you can create
   careers which are not in line with the racial restrictions (thus it
   IS possible to create a Human Trollslayer, if you wish to do so).
   This is not the case for gnomes, who simply cannot become rangers.

   If you specify a Career Class manually, the program will create a 
   character with the approriate career requirements.

   For certain careers, you can specify a subcareer. These careers are
   Thief, Entertainer and Artisan.
   
   Race-related skills are generated.

   The program does not account for Deity-dependant skills which can
   be taken on the different Cleric levels.

   Certain skills are considered innate. This means they can only be
   learned with the initial career, and never afterwards. These skills
   are 'Luck', 'Very Strong' and 'Very Resilient'.
   
   If a career trapping states 'Hand Weapon', the program will check
   if the character already has either a sword, an axe or a mace; if not
   it will choose one of the three.
   
   Some careers require 1 of 2 trappings (for example an Explorer needs
   either a merchant ship or a couple of muleteers and pack horses). In
   these cases the program will pick one randomly. These choices are
   built into the source code, and do not appear in the data files!!
   
   Names are generated using name lists, which are based on the name
   lists in the Warhammer Character Pack. Currently, gnomes and halfling
   use the same namelist as humans.
   
   The program keeps track of Experience Points spent. This way you can
   see how 'strong' you have made a character. 
      Experience Points are spent for:
        Getting a characteristic advance: 100 XP
        Learning a new skill: 100 XP (initial skills are free)
        Switching careers: 
          100 XP for a normal advancement
          50 XP for switching subcareers within a same career

   The program doesn't account for XP's which would have been needed for
   learning spells. This means the XP-score for magick-users is generally
   an underestimate of his/her 'strength'. 

!! Some careers already differ from the ones in the rulebook. Below is a
   list of changes we've made in our gaming group, because they seem logic
   to us. If you don't agree, you can edit the files to undo the changes.
     Muleskinner: has 'Specialist Weapon - Whip', instead of 'Flail Weapons'
     Prospector: does not get Attacks +1
     Artisan: gets 'Read/Write'
     Scholar: extra Career Exit: Lawyer
     Targeteer: does not get Attacks +1; instead get new skill Quick Draw
     *new skill* : Quick Draw: A character with this skill can fire a bow
			       rapidly with a reasonable accuracy. The
			       character may opt to fire 2 arrows each 
    			       round, at -20 BS each.
  

5. Data Files
-------------

   RANGER.SKL     Initial skill table for rangers
   ACADEMIC.SKL   Initial skill table for academics
   WARRIOR.SKL    Initial skill table for warriors
   ROGUE.SKL      Initial skill table for rogues

   HUMAN-F.NAM    Name table for female human names
   HUMAN-FC.NAM   Name table for compound female human names
   HUMAN-FO.NAM   Name table for old female human names (for academics)
   HUMAN-M.NAM    Name table for male human names
   HUMAN-MC.NAM   Name table for compound male human names (Karl-Franz)
   HUMAN-MO.NAM   Name table for old male human names (for academics)
   ELF-P.NAM      Elven name-prefixes table
   ELF-SF.NAM     Elven female name-suffixes table
   ELF-SM.NAM     Elven male name-suffixes table

   ACADEMIC.CAR   Academic Basic Career Table + career descriptions
   WARRIOR.CAR    Warrior Basic Career Table + career descriptions
   ROGUE.CAR      Rogue Basic Career Table + career descriptions
   RANGER.CAR     Ranger Basic Career Table + career descriptions
   ADVANCED.CAR   Advanced Career descriptions
   MAGICKAL.CAR   Magickal Career descriptions
   ENTERTAI.CAR   Entertainer Subcareers
   THIEVES.CAR    Thief Subcareers
   ARTISAN.CAR    Artisan Subcareers

   These files can be edited to change existing careers or add more
   careers. Please note if you add a new career, you may also have to
   edit the career-exits of some other careers. If you add a new basic
   career, you also have to edit the career-table at the beginning of
   the file. 
!! The program does not read the data-files intelligently. It follows
!! a rather rigid structure, so if you edit the data files, you will
!! have to follow the same structure as in the careers already given.
!! All lines in the datefiles are case-sensitive !!
!! Do not leave trailing spaces on the end of a line !!
   Although using the program is fairly straight-forward, editing the
   datafiles may not be. I apologize for the not-so-user-friendly
   structure of the data-files.

   As you are most likely to change the career data-files, I will give
   some explination below.
   
   At the top of either of the 4 Basic Career data-files, you will find
   a career table. This table consists of 5 columns of numbers and a
   column  with  career  names.  The first column of numbers is used for
   humans, the second for elves, the third for dwarves, the fourth for
   halflings and the last for gnomes. A D100 is used to determine the 
   career. If you add a new basic career, you must edit this list and
   make sure each column totals 100.

   Here is an example of a career description. Comments are given below.

   *Boatman
   Outlaw -War              
   Seaman -War            
   Smuggler -Rog
   xx
   0 10 10 0 0 2 10 0 0 0 0 10 0 0
   100 Fish
   100 Orientation
   100 River Lore
   100 Row
   50 Very Strong
   25 Consume Alcohol
   25 Boat Building
   0 xx
   100 Hand Weapon
   100 Leather Jacket
   100 Rowing Boat
   0 xx
   0
   
   Notes with the career description above:
     The '*' in front of the careername is required.
     The 3 lines below the careername are the Career Exits. Each Career
     Exit has a an '-' followed by a 3-letter code behind it, this is 
     required as well. The letter code refers to the datafile in which
     the Career Exit is described. (the first 3 letters of the file)
     The list of career exits is ended with a seperate line 'xx'.
     The next line is the Advance Scheme.
     Below the advance scheme are the skills. The number in front of
     each skill is the percantage of learning it with the initial
     career. (note: advanced careers still need the percentage (usually
     100) in front of them).
     The skill list is terminated by a seperate line '0 xx'
     Below this is the list of trappings, based on the same principal as
     the skill list, and also termineted with '0 xx'.
     The last number refers to the money associated with the career. The
     number mentiones the amount of D6 GC required (5 meaning 5D6). This
     number will be 0 for most careers.


6. Future
---------

   The following things will potentially be done in a somewhat distant and
   cloudy future:
      Eliminating the bugs that may be found
      Seperate data-files for each career (for easier editing)
      Intelligent data-file reading (eg. no case sensitivity,...)
      User specified innate skills
      Seperate name generation tables for Gnomes and Halflings (Help!)
      Further Character Background (place of birth, relatives, ...)
      Printing Capability
      Anything else you can think of?
     

7. Copyrights
-------------

Jester & Gnome Career Tables are taken from:
   "Out of the Garden", (c) Phil Gallagher (in White Dwarf 86)

All other career data are taken from:
   WFRP Rulebook, (c) Games Workshop and Hogshead
   
Name Generation is largely derived from:
   WFRP Character Pack, (c) Games Workshop

This program was  was written by Marco Van De Wiel. 
You may copy and distribute this program as much as you like, as long as
you don't pretend you wrote it. Please note that 'distribute' is not the
same as 'sell'. By no means can you ask money for this program!!
  

8. Disclaimer
-------------

   This program shouldn't do anything weird to your system. If something
   does go wrong while using this program, you're simply having a bad day.
   Don't blame me (blame Microsoft instead).


9. Registration
---------------

   Don't ask silly questions.


10. Source Code
---------------

Normally not available. Maybe if you ask really nice, but probably not.
The main reason is that I'm to emberrased to reveal such a sloppy 
program-structure to the outer-world. 




Contacting me:
    Marco Van De Wiel
    Kruisstraat 283
    3120 Tremelo
    Belgium
    marco.vandewiel@student.kuleuven.ac.be   (until september 1998)
