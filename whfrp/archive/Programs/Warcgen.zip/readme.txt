WARCGEN.ZIP - Warhammer Character Generator for MS-Windows 3.1 or higher.  
Follows all generation rules from Warhammer Fantasy RolePlay and Character
Background Generation Booklet.  Version 1.1.  July 1995.  
Author: Randy N. Carlson (carlsonr@bighorn.accessnv.com)in Visual Basic 3.0
with Access databases. Requires 4Meg RAM and 4Meg Disk. 